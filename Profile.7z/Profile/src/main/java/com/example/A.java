package com.example;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile({"A", "default"})
public class A implements Test1 {

    @Override
    public String display() {
        return "A";
    }

}