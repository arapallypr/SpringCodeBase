package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootApplication
public class ProfileApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(ProfileApplication.class, args);
	}

	@Autowired
	private Test1 T;

	@Override
	public void run(String... args) throws Exception {

		System.out.println(T.display());
	}

}
