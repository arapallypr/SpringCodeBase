package com.example;

public interface Test1 {

    String display();

}