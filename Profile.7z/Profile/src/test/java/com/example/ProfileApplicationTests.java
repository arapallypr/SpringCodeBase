package com.example;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({"B","A"})
public class ProfileApplicationTests {

    @Autowired
    Test1 T;

    @Test
    public void testRainingProfile() throws Exception {
        String output = T.display();
        assert(output).equals("A");
    }
}